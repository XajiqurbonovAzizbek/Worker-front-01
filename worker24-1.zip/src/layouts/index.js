import React from "react"

const AppLayout=React.lazy(()=>import("./AppLayout/AppLayout"))
export {AppLayout}