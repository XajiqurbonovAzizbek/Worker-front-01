import React from 'react'

export default function MakeOwner() {
  return (
    <div className='w-100 pt-3 d-flex justify-content-end align-items-center' style={{height:"4rem"}}>
        <div className='card rounded-3 p-1 d-flex justify-content-center align-items-center shadow-lg' style={{fontSize:"0.8rem",minWidth:"35%",backgroundColor:"var(--color-gray)"}}>© 2024-2050  “Worker” kunlik ishchilar  </div>
    </div>
  )
}
