import FirstWorkerRegister from "./FirstWorkerRegister/first.jsx"
import SecondWorkerRegister from "./SecondWorkerRegister/second.jsx"
import ThirdWorkerRegister from "./ThirdWorkerRegister/third.jsx"
import ForthWorkerRegister from "./FourthWorkerRegister/fourth.jsx"
export {FirstWorkerRegister,SecondWorkerRegister,ThirdWorkerRegister,ForthWorkerRegister}