import { ReactComponent as FlagUzIcon } from "./flag-UZ.svg"
import { ReactComponent as ListIcon } from "./list-icon.svg"
import { ReactComponent as PlusIcon } from "./plus-icon.svg"
import { ReactComponent as ListSuccessMuteIcon } from "./list-succes-mute-icon.svg"
import { ReactComponent as ListSuccessIcon } from "./list-success-icon.svg"
import { ReactComponent as PlaymarketDownloadIcon } from "./playmarket-download-icon.svg"
import { ReactComponent as AppstoreDowloadIcon } from "./appstore-dowload-icon.svg"
export { FlagUzIcon , ListIcon , PlusIcon ,ListSuccessMuteIcon , ListSuccessIcon , AppstoreDowloadIcon  ,PlaymarketDownloadIcon}